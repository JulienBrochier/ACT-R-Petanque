Ce projet mod�lise l�architecture cognitive mise en jeu durant une manche de p�tanque.
Il est constitu� de 2 fichiers�:
- petanque.lisp�: sert � g�n�rer la sc�ne et � lancer diff�rentes commandes d�taill�es dans le fichier ��commandes.txt��.
- petanque-model.lisp contenant le model ACT-, mod�lisant les taches cognitives.

Pour utiliser ce projet il est n�cessaire de charger le fichier petanque.lisp et d�avoir plac� le model � la racine d�ACT-R.

Les param�tres sont�:
sgp :v t :esc t :lf 0.4 :bll 0.5 :egs 3 :ans 0.2 :blc 0.5 :ol nil :rt 0 :ul t :ncnar nil :trace-detail low :visual-finst-span 5 :visual-num-finsts 7
:ut nil :alpha 0.2 :md 0


